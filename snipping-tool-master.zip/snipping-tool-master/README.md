## Snipping Tool in Python
A program which works like the snipping tool in Windows.

### Regular Snipping Tool (SnippingTool.py)
Link to the video

### Multi window Snipping Tool with paint options (SnippingMenu.py + SnippingTool.py)
[Link to the video](https://www.youtube.com/watch?v=bfOPA8Onp3Q)
